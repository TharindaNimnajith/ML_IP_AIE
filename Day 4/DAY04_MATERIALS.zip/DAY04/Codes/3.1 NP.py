import numpy as np

x=np.array([1,2,3,4,5,6,7,8,9])
y=x**2

print(x)
print(y)
