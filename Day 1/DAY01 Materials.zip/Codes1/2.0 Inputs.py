x=eval(input('Enter a number for x:'))
y=eval(input('Enter a number for y:'))

ans=x+y

print(ans)
