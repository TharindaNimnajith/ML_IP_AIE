x=(10,20,46,78,32,12,43,12)

print(sum(x))
print(max(x))

#x[2]=0
