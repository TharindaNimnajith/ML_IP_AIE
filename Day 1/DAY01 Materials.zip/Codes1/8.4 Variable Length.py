def func(a,b,*c):

    print(a,b,c)


func(10,20,30,40,50,60,'HELLO')
