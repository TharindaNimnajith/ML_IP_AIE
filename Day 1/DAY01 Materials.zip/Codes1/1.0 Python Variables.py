a=10
b=10.43
c="Hello World"
d='X'
e=(2+7j)

print(a)
print(b)
print(c)
print(d)
print(e)

print('=============')

a='AIE'

print(a)
