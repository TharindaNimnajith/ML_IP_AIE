##for i in range(0,10,1):
##
##    print(i)

list1=[10,34.6,'John','X',32,643]

##for i in list1:
##
##    print(i)


for i in range(0,6):

    print(list1[i])
