def calculator(a,b):

    add=a+b
    sub=a-b
    mult=a*b
    div=float(a)/float(b)

    return add,sub,mult,div
    
    #print(add,sub,mult,div)
    
answer=calculator(10,3)

print(answer)
