def func(a,b,c,d):

    print(a,b,c,d)


func(d=10,a=20.56,b='X',c='JOHN')
