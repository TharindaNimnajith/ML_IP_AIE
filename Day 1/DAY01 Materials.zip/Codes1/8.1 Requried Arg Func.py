def func(a,b,c,d):

    print(a,b,c,d)


func(10,20.56,'X','JOHN')

    
