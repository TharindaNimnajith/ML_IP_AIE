st1={45:1234,'name':'JOHN','maths':91,4.6:89,'chem':88}

print(st1[4.6])
