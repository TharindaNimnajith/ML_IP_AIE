def function1(a,b):

    c=a+b
    return c

ans=function1(10,20)
print('Answer=',ans)
