##import math
##
##print(math.pow(3,2))
##
##print(math.sin(math.pi/2))

##import math as m
##
##print(m.pow(3,2))

from math import sqrt

print(sqrt(4))
