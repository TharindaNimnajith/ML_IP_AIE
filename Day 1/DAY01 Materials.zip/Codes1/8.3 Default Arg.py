def func(a=0,b=0,c='N',d='EMPTY'):

    print(a,b,c,d)

func()
