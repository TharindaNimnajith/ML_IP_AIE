x=[10,20.23,'John','C',(6+2j)]

print(x)
print(len(x))
print(x[1:3])
print(x[1:])
print(x[:3])
