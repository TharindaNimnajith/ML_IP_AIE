for i in range(10):

     print(i)
     print('world')

print('Hello')


