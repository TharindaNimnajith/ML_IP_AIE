x=[10,20,46,78,32,12,43,12]

print(max(x))
print(min(x))
print(sum(x))

print('================')

x[2]=0

print(x)
