list1=[1,4,5,7,8,9,92,5,32]

print(list1)

list1.append('Hello')

print(list1)
