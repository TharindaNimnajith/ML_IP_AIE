#import math     ##include<string>

#print(math.pi)

#print(math.pow(2,3))

##import math as m
##
##print(m.pow(2,3))

from math import *

print(pow(2,3))
print(pi)
