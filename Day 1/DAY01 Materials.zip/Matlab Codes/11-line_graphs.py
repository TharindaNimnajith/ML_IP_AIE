from matplotlib import pyplot as plt


x=[0,1,2,3,4,5]
y=[0,5,6,8,3,12]

plt.plot(x,y)   # x vs y
plt.show()

