list1=[[67,'JK'],[89.09,'v'],[78,90]]

for i in list1:

    print(i)

##for i in range(5):
##
##    print(list1[i])
